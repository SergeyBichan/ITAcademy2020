package by.academy.task2.runner;


import by.academy.task2.rainbow.Rainbow;

public class RainbowRunner {
    public static void main(String[] args) {

        Rainbow rainbow = new Rainbow();
        rainbow.chooseColour((byte) 6);
        rainbow.chooseColourSecond((byte)1,(byte)3);


    }
}
